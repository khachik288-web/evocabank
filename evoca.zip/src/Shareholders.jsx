import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { FaFacebookF, FaLinkedinIn, FaInstagram } from 'react-icons/fa';

const PHOTO = 'https://www.evoca.am/file_manager/Shareholders/Mareta%20Gevorkyan%20Evocabank.png';

const ATTENTION = {
  intro:
    '«ԷՎՈԿԱԲԱՆԿ» ԲԲԸ-ի յուրաքանչյուր բաժնետեր, համաձայն «Բանկերի և բանկային գործունեության մասին» Հայաստանի Հանրապետության օրենքի 43-րդ հոդվածի 4-րդ մասի, իրավունք ունի ստանալու մեր վերջին տարեկան հաշվետվության և արտաքին աուդիտի եզրակացության պատճենները:',
  bullets: [
    '«ԷՎՈԿԱԲԱՆԿ» ԲԲԸ-ի տեղաբաշխված քվեարկող բաժնետոմսերի 2%-ին և ավելիին տիրապետող յուրաքանչյուր բաժնետեր իրավունք ունի ստանալու «Բանկերի և բանկային գործունեության մասին» Հայաստանի Հանրապետության օրենքի 43-րդ հոդվածի 4-րդ և 5-րդ մասերով սահմանված տեղեկությունները:',
    'Վերոնշյալ տեղեկությունները տրամադրում ենք ԱՆՎՃԱՐ՝ բաժնետիրոջ գրավոր դիմումը ստանալուց հետո 3 (երեք) աշխատանքային օրվա ընթացքում: Գրավոր դիմումը կարող է ներկայացվել առձեռն՝ մեր Գլխամասային գրասենյակում, ցանկացած մասնաճյուղում կամ ներկայացուցչությունում, էլեկտրոնային հասցեով՝ hello@evoca.am կամ փոստով՝ ՀՀ, 0010, ք. Երևան, Հանրապետության 44/2 հասցեով:',
    'Շահութաբաժինների բաշխումը կատարվում է ՀՀ օրենսդրական ակտերի համաձայն և Բանկի կանոնադրությամբ սահմանված կարգով:',
  ],
};

const CAPITAL = {
  intro: '2011թ. Բանկի կանոնադրական կապիտալը համալրվել է 7.2 մլրդ դրամով՝ կազմելով 14 մլրդ. 400 մլն. դրամ:',
  bullets: [
    'Մեր մասնակիցների 08.07.2016թ. արտահերթ ընդհանուր ժողովի որոշմամբ՝ Բանկը սահմանափակ պատասխանատվության ընկերությունից վերակազմավորվել է փակ բաժնետիրական ընկերության և մեր փաստացի համալրված կանոնադրական կապիտալը (14 մլրդ. 400 մլն. դրամ) բաժանվել է 144,000 հատ հասարակ բաժնետոմսերի, յուրաքանչյուրը՝ 100,000 դրամ անվանական արժեքով:',
    '2016թ. Բանկի կանոնադրական կապիտալը համալրվել է 3 մլրդ. 550 մլն. դրամով և կազմել 17 մլրդ. 950 մլն. դրամ: Մենք տեղաբաշխել ենք 100,000 դրամ անվանական արժեքով 35,500 հատ արտոնյալ բաժնետոմս:',
    '2020թ. Բանկի կանոնադրական կապիտալը համալրվել է 2 մլրդ. 50 մլն. դրամով և կազմել 20 մլրդ. դրամ: Այդ թվում` մենք տեղաբաշխել ենք նաև 29.05.2020թ. թողարկման 100,000 դրամ անվանական արժեքով 14,500 հատ արտոնյալ բաժնետոմս:',
    '2020թ. ՀՀ քաղաքացի Մարետա Գևորկյանը դարձել է Բանկի ուղղակի նշանակալից բաժնետերը:',
    '2022թ. ՀՀ քաղաքացի Մարետա Գևորկյանի կողմից Բանկի կանոնադրական կապիտալը համալրվել է 3 մլրդ. դրամով և կազմել 23 մլրդ. դրամ: Այդ թվում` մենք տեղաբաշխել ենք 12.03.2022թ. թողարկման 100,000 ՀՀ դրամ անվանական արժեքով 7,500 հատ արտոնյալ բաժնետոմս:',
  ],
};

const DIVIDENDS = [
  '2003-2006 թթ. մեր մասնակիցների միջև շահաբաժիններ չեն բաշխվել: Ընդհանուր ժողովի որոշմամբ՝ փաստացի ստացված զուտ շահույթն ուղղվել է մեր կանոնադրական հիմնադրամի համալրմանը կամ որպես չբաշխված շահույթ թողնվել մեր տրամադրության տակ:',
  '2006թ. 9 ամսվա գործունեություն արդյունքներով մեր մասնակիցներին միջանկյալ վճարվել է 80 մլն. դրամ շահաբաժին:',
  '2007թ. 9 ամսվա գործունեություն արդյունքներով մեր մասնակիցներին միջանկյալ վճարվել է 55 մլն. դրամ շահաբաժին:',
  '2008թ. փաստացի ստացված զուտ շահույթն Ընդհանուր ժողովի որոշմամբ թողնվել է մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2009թ. Ընդհանուր ժողովի որոշմամբ՝ փաստացի ստացված զուտ շահույթից 70 մլն. դրամ վճարվել է մեր մասնակիցներին, իսկ մնացած մասը՝ թողնվել մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2010-2012 թթ. փաստացի ստացված զուտ շահույթը, Ընդհանուր ժողովի որոշմամբ, թողնվել է մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2013թ. փաստացի ստացված զուտ շահույթից 895 մլն. դրամ վճարվել է մեր մասնակիցներին, իսկ մնացած մասը՝ թողնվել մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2014թ. փաստացի ստացված զուտ շահույթը, Ընդհանուր ժողովի որոշմամբ, թողնվել է մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2015թ. փաստացի ստացված զուտ շահույթը, Ընդհանուր ժողովի որոշմամբ, թողնվել է մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2016թ. փաստացի ստացված զուտ շահույթը, Ընդհանուր ժողովի որոշմամբ, թողնվել է մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2017թ. փաստացի ստացված զուտ շահույթից 78 մլն. դրամ վճարվել է մեր մասնակիցներին, իսկ մնացած մասը՝ թողնվել մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2018թ. փաստացի ստացված զուտ շահույթից 426 մլն. դրամ վճարվել է մեր մասնակիցներին, իսկ մնացած մասը՝ թողնվել մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2019թ. փաստացի ստացված զուտ շահույթից 426 մլն. ՀՀ դրամ վճարվել է մեր մասնակիցներին, իսկ մնացած մասը՝ թողնվել մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2020թ. փաստացի ստացված զուտ շահույթից 426 մլն. ՀՀ դրամ վճարվել է մեր մասնակիցներին, իսկ մնացած մասը՝ թողնվել մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2021թ. փաստացի ստացված զուտ շահույթից 482 մլն. ՀՀ դրամ վճարվել է մեր մասնակիցներին, իսկ մնացած մասը՝ թողնվել մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
  '2022թ. փաստացի ստացված զուտ շահույթից 571 մլն. դրամ վճարվել է մեր մասնակիցներին, իսկ մնացած մասը՝ թողնվել մեր տրամադրության տակ՝ որպես չբաշխված շահույթ:',
];

const DOCS = ['Կանոնադրություն', 'Բանկային գործունեության լիցենզիա', 'Բանկի Գրանցման վկայականը'];

function Chevron({ open }) {
  return (
    <svg
      className={`h-4 w-4 shrink-0 text-purple-700 transition-transform duration-300 ${open ? 'rotate-180' : ''}`}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="3"
    >
      <path d="M6 9l6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function AccordionItem({ title, children }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mb-3 overflow-hidden rounded-2xl border border-purple-200 bg-white">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-4 px-5 py-4 text-left"
        aria-expanded={open}
      >
        <Chevron open={open} />
        <span className="text-[15px] font-semibold text-gray-500">{title}</span>
      </button>
      {open && <div className="border-t border-purple-100 px-6 py-5 text-[15px] leading-relaxed text-gray-700">{children}</div>}
    </div>
  );
}

function BulletList({ items }) {
  const { t } = useTranslation();
  return (
    <ul className="mt-3 list-disc space-y-2 pl-6">
      {items.map((item, i) => (
        <li key={i}>{t(item)}</li>
      ))}
    </ul>
  );
}

function DocIcon() {
  return (
    <svg className="h-6 w-6 shrink-0 text-purple-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      <path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h4" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M14 3l5 5v3" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M14 3v5h5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="17" cy="17" r="4.5" />
      <path d="M17 14.8v4.4m0 0l-1.6-1.6m1.6 1.6l1.6-1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function Shareholders() {
  const { t } = useTranslation();
  return (
    <main className="relative bg-white pb-20 text-gray-900">
      {/* Social bar */}
      <div className="absolute left-8 top-[76px] hidden flex-col gap-3 rounded bg-gray-100 px-3 py-3 text-gray-500 xl:flex">
        <a href="#fb" className="text-reset hover:text-purple-700"><FaFacebookF size={13} /></a>
        <a href="#in" className="text-reset hover:text-purple-700"><FaLinkedinIn size={14} /></a>
        <a href="#ig" className="text-reset hover:text-purple-700"><FaInstagram size={14} /></a>
      </div>

      <div className="mx-auto max-w-[900px] px-6 pt-4">
        <h1 className="mb-12 text-[28px] font-normal tracking-wide text-gray-800">{t('Բաժնետերեր')}</h1>

        {/* Shareholder card */}
        <div className="flex flex-col gap-6 md:flex-row">
          <img
            src={PHOTO}
            alt={t('Մարետա Գևորկյան')}
            className="h-[254px] w-[204px] shrink-0 object-cover"
          />
          <div>
            <h2 className="mb-5 text-[20px] font-semibold italic text-purple-700">{t('Մարետա Գևորկյան')}</h2>
            <p className="text-[15px] leading-[1.6] text-gray-800">
              {t('Մարետա Գևորկյանը միանձնյա տիրապետում է Evocabank-ի բաժնետոմսերի 100%-ին:')}
              <br />
              {t('Նա ծնվել է Դիլիջանում, ավարտել Դիլիջանի միջնակարգ դպրոցը, այնուհետև՝ Երևանի պետական մանկավարժական ակադեմիան:')}
              <br />
              {t('2008 թվականից բնակվելով Շվեյցարիայում՝ նա ակտիվորեն ներգրավված է բանկային, տարածքային զարգացման և սոցիալական նախաձեռնություններում՝ նպաստելով Հայաստանի կայուն զարգացմանը:')}
              <br />
              <br />
              <strong>{t('Նշում.')} </strong>{t('Բանկն անուղղակի նշանակալից մասնակից չունի.')}
            </p>
          </div>
        </div>

        {/* Info accordions */}
        <h2 className="mb-6 mt-16 text-[20px] font-extrabold uppercase tracking-wide text-gray-900">{t('Անհրաժեշտ տեղեկատվություն')}</h2>

        <AccordionItem title={t('Ուշադրություն')}>
          <p>{t(ATTENTION.intro)}</p>
          <BulletList items={ATTENTION.bullets} />
        </AccordionItem>

        <AccordionItem title={t('Տեղեկատվություն մեր կանոնադրական կապիտալի փոփոխության վերաբերյալ')}>
          <p>{t(CAPITAL.intro)}</p>
          <BulletList items={CAPITAL.bullets} />
        </AccordionItem>

        <AccordionItem title={t('Տեղեկատվություն շահաբաժինների բաշխման վերաբերյալ')}>
          <BulletList items={DIVIDENDS} />
        </AccordionItem>

        {/* Documents */}
        <section className="mx-auto mt-14 max-w-[720px]">
          <h3 className="mb-5 text-[19px] font-bold text-gray-900">{t('Փաստաթղթեր')}</h3>
          <div className="flex flex-col gap-5">
            {DOCS.map((d) => (
              <a
                key={d}
                href="#"
                className="flex items-center gap-3 rounded bg-[#f5f3f8] px-3 py-3 text-[13px] font-semibold text-gray-900 no-underline transition-colors hover:bg-[#ece7f5] hover:no-underline"
              >
                <DocIcon />
                <span>{t(d)}</span>
              </a>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
