import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, ChevronDown, Home, FileDown } from 'lucide-react';
import { FaFacebookF, FaLinkedinIn, FaInstagram } from 'react-icons/fa';
import { FloatingActions } from './Loans';
import OnlineBanner from './OnlineBanner';
import './CardsService.css';
import { onDownload } from './downloadFile';
import { useTranslation } from 'react-i18next';

const ISSUE_POINTS = [
  'Բանկը հաճախորդներին տրամադրում է Հաշվարկային կամ Վարկային՝ «ArCa» լոգոյով, «Visa», «Mastercard» և «UnionPay» միջազգային վճարային համակարգերի քարտեր։',
  'Քարտային հաշիվները բացվում և վարվում են ՀՀ դրամով, ԱՄՆ դոլարով, ԵՎՐՈ-ով և ՌԴ ռուբլով։',
  'Արագ փոխանցման համակարգերով ստացված գումարներ հաճախորդի կարգադրությամբ կարող են հաշվեգրվել նաև հաճախորդի Բանկում ունեցած այլ Քարտային հաշվին։',
  'Բանկը դիմումի համաձայն Քարտապանի կողմից լիազորված անձանց կարող է տրամադրել Լրացուցիչ քարտեր։ Քարտային հաշիվը տնօրինում է հիմնական Քարտի Քարտապանը։ Հիմնական Քարտի Քարտապանը պատասխանատվություն է կրում տրամադրված բոլոր Լրացուցիչ Քարտերով իրականացված գործարքների համար։ Լրացուցիչ քարտը կարող է տրամադրվել անմիջականորեն այն օգտագործողին միայն հիմնական Քարտապանի նախապես ներկայացված գրավոր համաձայնության դեպքում։',
  'Բանկը Քարտապանի Քարտային հաշվի դրական մնացորդի նկատմամբ հաշվեգրում է տոկոսագումարներ, տոկոսադրույքի չափը սահմանվում է Բանկի սակագներով։',
  'Վճարային Քարտը Քարտապանին է տրամադրվում Բանկի գլխամասային գրասենյակում, մասնաճյուղերում, ինչպես նաև առաքման միջոցով՝ Վճարային քարտի ստացման դիմումը ներկայացնելուն հաջորդող 7 (յոթ) աշխատանքային օրվա ընթացքում։',
  'Քարտապանը Վճարային քարտը ստանալիս պետք է ներկայացնի անձը հաստատող այն փաստաթուղթը, որով դիմել է քարտի համար (անձնագիր կամ նույնականացման քարտ)։',
  'Բանկը Քարտապանին Վճարային Քարտը կարող է տրամադրել PIN ծածկագրով կամ առանց PIN ծածկագրի։ Վճարային Քարտը և PIN ծածկագիրը Քարտապանին տրամադրվում են առանձին փակ ծրարներով։ Վճարային Քարտը առանց PIN ծածկագրի տրամադրման դեպքում քարտի ակտիվացումը և Հաճախորդի կողմից PIN ծածկագրի սահմանումը կատարվում է Հաճախորդի համար Բանկում գրանցված հեռախոսահամարին ստացված OTP գաղտնաբառի միջոցով։',
  'Քարտը և PIN ծածկագիրը ստանալուն պես Քարտապանը պետք է ստուգի ծրարի փակ և անվնաս լինելը, քարտի և PIN- ծածկագրի առկայությունը ծրարում, համապատասխանությունը քարտի պատվիրման հայտին, ինչպես նաև քարտի վրա նշված տվյալների ճշտությունը։ Անհամապատասխանությունների դեպքում Քարտապանը պետք է անմիջապես տեղեկացնի Բանկին։',
  'Վճարային Քարտը ստանալուց պես Քարտապանը պարտավոր է անմիջապես ստորագրել Վճարային Քարտի հակառակ կողմի վրա ստորագրության համար նախատեսված մասում։ Վճարային Քարտի հակառակ կողմում ստորագրության բացակայությունը կամ դրա անհամապատասխանությունը օրինական հիմք է քարտի սպասարկումը մերժելու և այն առգրավելու համար։',
  'Բանկի կողմից Վճարային Քարտերը տրամադրվում են մինչև 5 (հինգ) տարի ժամկետով։',
  'Հաճախորդի ներկայացրած դիմումի հիման վրա Բանկը կարող է վարկավորել Հաճախորդի Քարտային հաշիվը՝ վերջինիս հետ կնքելով համապատասխան վարկային սահմանաչափի տրամադրման պայմանագիր։',
  'Եթե Հաճախորդը Վճարային քարտը պատվիրելուց հետո 30 օրացուցային օրվա ընթացքում չի դիմում Բանկ Վճարային քարտը ստանալու համար, ապա Բանկը կարող է ոչնչացնել Վճարային քարտը՝ փակելով քարտային հաշիվը, և չվերադարձնել գանձված միջնորդավճարները։',
];

// Временный общий текст для пунктов, у которых пока нет собственного содержимого (замени на настоящий points: [...]).
const PLACEHOLDER_POINTS = [
  'Սույն բաժնի վերաբերյալ մանրամասն տեղեկատվությունը սահմանվում է Բանկի կողմից հաստատված Վճարային քարտերի տրամադրման և սպասարկման պայմաններով և գործող սակագներով։',
  'Քարտի հետ կապված ցանկացած հարցի դեպքում կարող եք դիմել Բանկի ցանկացած մասնաճյուղ կամ զանգահարել կարճ համարով՝ 8444։',
  'Ձեր քարտային գործառնությունների անվտանգությունն ապահովելու նպատակով խորհուրդ ենք տալիս երբեք չհայտնել քարտի PIN ծածկագիրը և CVV կոդը երրորդ անձանց։',
];

const ACCORDION = [
  { title: 'Քարտի տրամադրում և ակտիվացում', points: ISSUE_POINTS },
  { title: 'Վճարային քարտի վճարներ և գանձումներ', points: PLACEHOLDER_POINTS },
  { title: 'Վճարային Քարտի օգտագործման, պահպանման և անվտանգության կանոնները', points: PLACEHOLDER_POINTS },
  { title: 'Վճարային Քարտի օգտագործումը', points: PLACEHOLDER_POINTS },
  { title: 'Արտարժույթով արտահայտված գործառնությունների կատարում', points: PLACEHOLDER_POINTS },
  { title: 'Վճարային Քարտի առգրավում/բռնագանձում', points: PLACEHOLDER_POINTS },
  { title: 'Վճարային Քարտի բլոկավորում/ապաբլոկավորում', points: PLACEHOLDER_POINTS },
  { title: 'Վճարային Քարտի վերաթողարկում', points: PLACEHOLDER_POINTS },
  { title: 'Քարտային գործառնությունների բողոքարկում', points: PLACEHOLDER_POINTS },
  { title: 'Քարտային հաշվի վերաբերյալ տեղեկատվության և Քաղվածքի տրամադրում', points: PLACEHOLDER_POINTS },
  { title: 'Վճարային Քարտի փակում', points: PLACEHOLDER_POINTS },
  { title: 'Օտարերկրյա Հաշիվների Հարկման Համապատասխանության ակտի (FATCA) ծանուցում', points: PLACEHOLDER_POINTS },
  { title: 'Քարտային գործառնությունների մոնիտորինգ և անվտանգություն', points: PLACEHOLDER_POINTS },
  { title: 'Քարտի թոքենացում և մոբայլ (NFC) վճարումներ', points: PLACEHOLDER_POINTS },
  { title: 'Հնարավոր զեղծարարություններից խուսափելու համար։', points: PLACEHOLDER_POINTS },
];

const DOCS = [
  'Կենսաթոշակային քարտեր',
  'Evoca Gift քարտեր (Տեղեկատվական ամփոփագիր)',
  'Տեղեկատվական ամփոփագիր (Բանկային հաշիվներ) 08.06.26',
  'Visa Digital քարտեր (Տեղեկատվական ամփոփագիր)',
  '«ԷՎՈԿԱԲԱՆԿ» ԲԲԸ վճարային քարտերի կիրառմամբ EvocaTouch բջջային հավելվածով թվայնացված քարտերի օգտագործման պայմաններ',
  'Visa Infinite քարտեր (Տեղեկատվական ամփոփագիր)',
  'UnionPay Business Platinum քարտեր (Տեղեկատվական ամփոփագիր)',
  'UnionPay UPI Gold քարտեր (Տեղեկատվական ամփոփագիր)',
  'Visa Vision քարտեր (Տեղեկատվական ամփոփագիր)',
  'Mastercard World Digital (Տեղեկատվական ամփոփագիր)',
  'Dalma Gift քարտեր (Տեղեկատվական ամփոփագիր)',
  "Garage Masters' Mall Gift քարտեր",
  'Digital Gift քարտեր (Տեղեկատվական ամփոփագիր)',
  'Rio Gift քարտեր (Տեղեկատվական ամփոփագիր)',
  'MBG Gift քարտեր (Տեղեկատվական ամփոփագիր)',
  'Վճարային քարտերի տրամադրման և սպասարկման պայմաններ 01.02.2026թ',
  'Համալիր բանկային ծառայությունների մատուցման պայմաններ 16.05.2025թ.',
  'Դեբետային և կրեդիտային քարտեր (Տեղեկատվական ամփոփագիր) 17.03.2026',
  'Evoca Travel (Տեղեկատվական ամփոփագիր) 17.03.2026',
  'Visa Platinum քարտեր (Տեղեկատվական ամփոփագիր)',
  'Տեղեկատվական ամփոփագիր (arca UPI cobadge)',
  'USSD և 3D Secure ծառայություն',
];

function AccItem({ item, open, onToggle }) {
  const { t } = useTranslation();
  return (
    <div className={`svc-item${open ? ' is-open' : ''}`}>
      <button type="button" className="svc-head" onClick={onToggle} aria-expanded={open}>
        <ChevronDown size={18} className="svc-chev" />
        <span>{t(item.title)}</span>
      </button>
      <div className="svc-panel">
        <div>
          {item.points ? (
            <ol className="svc-list">
              {item.points.map((p, i) => <li key={i}>{t(p)}</li>)}
            </ol>
          ) : (
            <p className="svc-soon">{t('Տեղեկատվությունը շուտով կհրապարակվի։')}</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default function CardsService() {
  const { t } = useTranslation();
  const [openIdx, setOpenIdx] = useState(0);

  return (
    <main className="svc-page">
      <div className="svc-wrap">
        <nav className="svc-crumbs">
          <Link to="/" aria-label="Home"><Home size={16} /></Link>
          <ChevronRight size={12} />
          <Link to="/">{t('Անհատ')}</Link>
          <ChevronRight size={12} />
          <Link to="/cards">{t('Քարտեր')}</Link>
          <ChevronRight size={12} />
          <span>{t('Քարտերի տրամադրում և սպասարկում')}</span>
        </nav>

        <div className="svc-body">
          <div className="svc-share">
            <a href="#" aria-label="Facebook" onClick={(e) => e.preventDefault()}><FaFacebookF size={14} /></a>
            <a href="#" aria-label="LinkedIn" onClick={(e) => e.preventDefault()}><FaLinkedinIn size={16} /></a>
            <a href="#" aria-label="Instagram" onClick={(e) => e.preventDefault()}><FaInstagram size={15} /></a>
          </div>

          <div className="svc-content">
            <h1 className="svc-title">{t('Քարտերի տրամադրում և սպասարկում')}</h1>
            <h2 className="svc-heading">{t('Անհրաժեշտ տեղեկատվություն')}</h2>

            <div className="svc-acc">
              {ACCORDION.map((item, i) => (
                <AccItem
                  key={item.title}
                  item={item}
                  open={openIdx === i}
                  onToggle={() => setOpenIdx(openIdx === i ? -1 : i)}
                />
              ))}
            </div>
          </div>

          <section className="svc-docs">
            <h2>{t('Փաստաթղթեր')}</h2>
            <ul className="svc-doc-list">
              {DOCS.map((d) => (
                <li key={d}>
                  <a href="#" className="svc-doc" onClick={onDownload(d)}>
                    <FileDown size={26} strokeWidth={1.5} />
                    <span>{t(d)}</span>
                  </a>
                </li>
              ))}
            </ul>
          </section>
        </div>
        <div className="svc-bottom" />
      </div>

      <OnlineBanner />

      <div className="svc-updated"><div>{t('Թարմացվել է՝')} 02/09/2026 14:33</div></div>

      <FloatingActions />
    </main>
  );
}